
/**
 * This is the class to simulate 4 players playing the game.
 * @author Yuehong Zhang 3109345 Assignment 1 part A
 */
import java.util.Random;

public class Driver {

    public static void main(String[] args) {
        //Create 4 players
        Player player1 = new Player("Harry");//create player1
        Player player2 = new Player("Ron");//create player2
        Player player3 = new Player("Hermione");//create player3
        Player player4 = new Player("Luna");//create player4
        
        //Create a new CircularlyLinkedList to store 4 player.
        CircularlyLinkedList<Player> playerList = new CircularlyLinkedList<>();
        playerList.addLast(player1);//add first player to the list
        playerList.addLast(player2);//add second player to the list
        playerList.addLast(player3);//add third player to the list
        playerList.addLast(player4);//add fourth player to the list
        
        //Creat a new CircularlyLinkedList to store eliminated players.
        CircularlyLinkedList<Player> eliminatedList = new CircularlyLinkedList<>();
        int numOfeliminated = 0;//variable to store the number of players eliminated
       
        boolean someoneWin = false;// variable to know if some one wins
        Player winner = null;//variable to store the winner
        
        while (!someoneWin) { //game continues until someone win
            int numOfPlayersInList = playerList.size(); //know the number of players for now
            
            //a new round of game 
            for (int i = 0; i < numOfPlayersInList; i++) {//everyone in the list rolls
                Player player = playerList.first();//the player in the list who's turn to roll
                
                //check if there is only one player now
                if (playerList.size() == 1) {//if there is only 1 player left
                    someoneWin = true;// some one wins
                    winner = player;// the only player left is the winner
                    break;//if win, no need to play now, break out 
                }
                
                int scoreOfPlayer = player.getScore();//get player's score for now
                String playerName = player.getName();//get player's name
                Random r = new Random();//create a Random object to generate random number
                int firstDiceScore = r.nextInt(6) + 1;//get a random number for first dice
                int secondDiceScore = r.nextInt(6) + 1;//get a random number for second dice
                int thirdDiceScore = r.nextInt(6) + 1;//get a random number for third dice
                int totalRollScore = firstDiceScore + secondDiceScore + thirdDiceScore;//get the total roll value

                //If a player’s roll results in a total of 9, their score is decreased by 9 points
                if (firstDiceScore + secondDiceScore + thirdDiceScore == 9) {// if an unlucky 9
                    scoreOfPlayer -= 9;//decrease 9 points
                    if (scoreOfPlayer < 0) {//if socre <0 after decrease
                        scoreOfPlayer = 0;//socre will still be 0
                    }
                     player.setScore(scoreOfPlayer);//set the score of the player
                    //display the roll result and score now
                    System.out.println(playerName + " rolled unlucky 9, score is now " + scoreOfPlayer);
                } else if (firstDiceScore == 6 && secondDiceScore == 6 && thirdDiceScore == 6) {
                    //If a player rolls a set (3) of 6s, score is reset to 0
                    scoreOfPlayer = 0;//reset score to 0
                    player.setScore(scoreOfPlayer);//set the score of the player
                    System.out.println(playerName + " rolled a triple 6, score is back to 0");//display the roll result
                } else if (firstDiceScore == 1 && secondDiceScore == 1 && thirdDiceScore == 1) {
                    // If the player rolls a set (3) of 1s, they are eliminated from the game
                    //display the roll result
                    System.out.println(playerName + " rolled snake eyes (three 1’s) and has been eliminated :(");
                    playerList.removeFirst(); //remove the player from the list.
                    eliminatedList.addLast(player);//add this player to eliminated List
                    numOfeliminated++;//number of eliminated player increment
                    break;// no need for more action
                } else {// if none of situtions above happens
                    scoreOfPlayer += totalRollScore;//score increased
                    player.setScore(scoreOfPlayer);//set the score of the player
                    // display the roll result and score
                    System.out.println(playerName + " rolled " + totalRollScore + ", score is now " + scoreOfPlayer);
                    //check if this player wins 
                    if (scoreOfPlayer >= 150) {//if player's score reaches 150
                        someoneWin = true;//some one win
                        winner = player;// player is the winner
                        break;// no need for more action
                    }
                }
                //if player not removed and no one wins for now,rotate list for next player to play.
                playerList.rotate();
            }
        }
        
        // some one win now, so display the winner
        System.out.println(winner.getName() + " has won the game!:)");
        System.out.println("Final scores are:"); 
        // list all the scores of players who is still in the player list
        for (int i = 0; i < playerList.size(); i++) {//loop through the player list
            String playerName = playerList.first().getName();//get player's name
            int PlayerScore = playerList.first().getScore();//get player's score
            System.out.print(playerName + ": " + PlayerScore);//display player's score
            if(i<playerList.size()-1)//if not the last player
                System.out.print(", ");//display a comma behind
            playerList.rotate();//rotate list to get next player
        }
        System.out.println();
        //display the eliminated player names;
        if (numOfeliminated > 0) {//if someone in the eliminated player list
            System.out.print("(Eliminated: ");//list the eliminated player names
            for (int i = 0; i < numOfeliminated; i++) {//loop through the eliminated player list
                System.out.print(eliminatedList.first().getName());//display the eliminated player's name
                if (i < numOfeliminated - 1) {//if this is not the last player in eliminated player list
                    System.out.print(", ");//display a comma behind
                }
                eliminatedList.rotate();//rotate the list to get next player.
            }
            System.out.println(")");//the end of the eliminated player list. 
        }

    }
}
