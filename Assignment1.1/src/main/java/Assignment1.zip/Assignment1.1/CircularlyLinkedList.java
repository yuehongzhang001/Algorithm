/**
 * This is the generic CircularlyLinkedList class from textbook
 * @author Yuehong Zhang 3109345 Assignment 1 part A
 */
public class CircularlyLinkedList<E> {
    //---------------- nested Node class ----------------
    private static class Node<E> {
        private E element;//variable to store element
        private Node<E> next;//variable to store next node
        public Node(E e, Node<E> n){ //constructor
            element = e;
            next = n;
        }
        public E getElement(){return element;} //return the element
        public Node<E> getNext(){return next;} //get next node
        public void setNext(Node<E> n){ next = n;} //set next node
    }//---------------- End of nested Node class ----------------
    
    // instance variables of the CircularlyLinkedList
    private Node<E> tail = null; //tail node of the list(null if empty)
    private int size = 0; // number of nodes in the list
    public CircularlyLinkedList(){} //// constructs an initially empty list
    
    public int size(){return size;} // access method of list size;
    public boolean isEmpty(){return size==0;}// method to check if list is empty
    
    /**
     * the method to access the element in first Node.
     * @return the first element value
     */
    public E first(){
        if(isEmpty())return null;//return null if list is empty
        return tail.getNext().getElement();//first element value
    }
    /**
     * the method to access the element in last Node.
     * @return the last element value
     */
    public E last(){
        if(isEmpty())return null;//return null if list is empty
        return tail.getElement();//last element value
    }
    
   
    /**
     * this method rotates the first element to the back of list
     */
    public void rotate(){
        if(!isEmpty())   //if not empty, rotate the list
            tail = tail.getNext(); // set the first node to be the tail.
    }
    /**
     * this method adds an element to the head of the list
     * @param e the element to add to the head
     */
    public void addFirst(E e){
        if(isEmpty()) {
            tail = new Node<>(e,null); //create a new node and pointed by tail.
            tail.setNext(tail); //link to itself circularly
        }else{
            Node<E> newest = new Node<>(e,tail.getNext());//create a new node which links to first node
            tail.setNext(newest);//set the tail node to link to new node, new node become first node
        }
        size++; //size increment
    }
    
    /**
     * this method adds an element to the end of the list
     * @param e the element to add to the tail
     */
    public void addLast(E e){
        addFirst(e);//insert new element at the front of list
        tail = tail.getNext(); //now the new element become the tail
    }
    /**
     * this method remove and return the first element
     * @return the element that is removed
     */
    public E removeFirst(){
        if(isEmpty()) return null; //nothing to remove
        Node<E> head = tail.getNext(); // get the head node
        if(tail == head)tail = null; //if only one node left, remove it
        else tail.setNext(head.getNext());//remove heads from list
        size--; //decrease size
        return head.getElement(); //return the removed element
    }
    
}


